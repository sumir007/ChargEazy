using Chargeazy.Models;
using Microsoft.EntityFrameworkCore;

namespace Chargeazy
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddDbContext<UserDbContext>(options =>
            {
                options.UseNpgsql(builder.Configuration.GetConnectionString("pgconstr"));

            });

            builder.Services.AddScoped<IUserDataAccess, UserDataAccess>();
            builder.Services.AddDbContext<CharStnDbContext>(options => {
                options.UseNpgsql(builder.Configuration.GetConnectionString("pgconstr"));

            });

            builder.Services.AddScoped<ICharStnDataAccess, CharStnDataAccess>();
            builder.Services.AddDbContext<CharProDbContext>(options => {
                options.UseNpgsql(builder.Configuration.GetConnectionString("pgconstr"));

            });

            builder.Services.AddScoped<ICharProDataAccess, CharProDataAccess>();
            builder.Services.AddDbContext<RevDbContext>(options =>
            {
                options.UseNpgsql(builder.Configuration.GetConnectionString("pgconstr"));

            });

            builder.Services.AddScoped<IRevDataAccess, RevDataAccess>();
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowReactApp",
                    builder => builder
                        .WithOrigins("http://localhost:3000") // Replace with your React app's URL
                        .AllowAnyHeader()
                        .AllowAnyMethod());
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();
            app.UseCors("AllowReactApp");

            app.Run();
        }
    }
}