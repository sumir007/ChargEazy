﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Chargeazy.Migrations.CharStnDb
{
    public partial class Initial_Create3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
