﻿namespace Chargeazy.Models
{
    public class UserDataAccess : IUserDataAccess
    {
        readonly UserDbContext _dbCtx;
        public UserDataAccess(UserDbContext dbCtx)
        {
            this._dbCtx = dbCtx;
            
        }
        public void AddUser(User u)
        {
            _dbCtx.Users.Add(u);
            _dbCtx.SaveChanges();
        }

        public void DeleteUser(int UserId)
        {
            var record = _dbCtx.Users.Find(UserId);
            if (record != null)
            {
                _dbCtx.Users.Remove(record);
                _dbCtx.SaveChanges();
            }
        }

        public List<User> GetUser()
        {
            return _dbCtx.Users.ToList();
        }

        public string GetUserById(string Email)
        {
            var record = _dbCtx.Users.Find(Email);
            if (record != null)
            {
                return record.Password;
            }
            else
            {
                throw new Exception("Record Not Found");
            }
        }

        public void UpdateUser(User u)
        {
            var record = _dbCtx.Users.Find(u.UserId);
            if (record != null)
            {
                record.Username = u.Username;
                record.Email = u.Email;
                record.Password = u.Password;
                record.Location = u.Location;
                _dbCtx.SaveChanges();

            }
            else
            {
                throw new Exception("Record not Found");
            }
        }
    }
}
