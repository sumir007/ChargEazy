﻿namespace Chargeazy.Models
{
    public class CharStnDataAccess : ICharStnDataAccess
    {
        readonly CharStnDbContext _dbCtx1;
        public CharStnDataAccess(CharStnDbContext dbCtx1)
        {
            this._dbCtx1 = dbCtx1;

        }
        public void AddStn(CharStn c)
        {
            _dbCtx1.CharStns.Add(c);
            _dbCtx1.SaveChanges();
        }

        public List<CharStn> GetStn()
        {
            return _dbCtx1.CharStns.ToList();
        }

        public CharStn GetStnById(int StationId)
        {
            var record = _dbCtx1.CharStns.Find(StationId);
            if (record != null)
            {
                return record;
            }
            else
            {
                throw new Exception("Record Not Found");
            }
        }

        public void UpdateStn(CharStn c)
        {
            var record = _dbCtx1.CharStns.Find(c.StationId);
            if (record != null)
            {
                record.Stationname = c.Stationname;
                record.ProviderId = c.ProviderId;
                record.Location = c.Location;
                record.Address = c.Address;
                record.ChargingCapacity = c.ChargingCapacity;
                record.Status = c.Status;
                _dbCtx1.SaveChanges();

            }
            else
            {
                throw new Exception("Record not Found");
            }
        }
    }
}
