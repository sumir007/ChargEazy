﻿namespace Chargeazy.Models
{
    public interface ICharStnDataAccess
    {
        List<CharStn> GetStn();
        CharStn GetStnById(int StationId);
        void AddStn(CharStn c);
        void UpdateStn(CharStn c);
    }
}
