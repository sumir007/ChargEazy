﻿using Microsoft.EntityFrameworkCore;

namespace Chargeazy.Models
{
    public class RevDbContext: DbContext
    {
        public RevDbContext(DbContextOptions<RevDbContext> options)
          : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Review>()
                .HasKey(r => r.ReviewId); // Assuming 'Id' is the primary key property

            // Other entity configurations here

            base.OnModelCreating(modelBuilder);
        }
        public DbSet<Review> Reviews { get; set; }
    }
}
