﻿namespace Chargeazy.Models
{
    public interface IRevDataAccess
    {
        List<Review> GetRev();
        Review GetRevById(int RevId);
        void AddRev(Review r);

    }
}
