﻿using Microsoft.EntityFrameworkCore;

namespace Chargeazy.Models
{
    public class CharStnDbContext : DbContext
    {
        public CharStnDbContext(DbContextOptions<CharStnDbContext> options)
           : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CharStn>()
                .HasKey(c => c.StationId); // Assuming 'Id' is the primary key property

            // Other entity configurations here

            base.OnModelCreating(modelBuilder);
        }
        public DbSet<CharStn> CharStns { get; set; }
    }
}
