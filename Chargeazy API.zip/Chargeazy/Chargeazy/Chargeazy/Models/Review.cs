﻿namespace Chargeazy.Models
{
    public class Review
    {
        public int ReviewId { get; set; }
        public int UserId { get; set; }
        public int StnId { get; set; }
        public int Rating { get; set;}
        public string Comment { get; set;}

    }
}
