﻿using Microsoft.EntityFrameworkCore;

namespace Chargeazy.Models
{
    public class CharProDbContext : DbContext
    {
        public CharProDbContext(DbContextOptions<CharProDbContext> options)
           : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CharPro>()
                .HasKey(p => p.ProId); // Assuming 'Id' is the primary key property

            // Other entity configurations here

            base.OnModelCreating(modelBuilder);
        }
        public DbSet<CharPro> CharPros { get; set; }
    }
}
