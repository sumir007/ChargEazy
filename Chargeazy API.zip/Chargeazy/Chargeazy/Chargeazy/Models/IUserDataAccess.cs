﻿namespace Chargeazy.Models
{
    public interface IUserDataAccess
    {
        List<User> GetUser();
        string GetUserById(string Email);
        void AddUser(User u);
        void DeleteUser(int UserId);
        void UpdateUser(User u);
    }
}
