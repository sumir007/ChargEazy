﻿namespace Chargeazy.Models
{
    public class CharProDataAccess : ICharProDataAccess
    {
        readonly CharProDbContext _dbCtx2;
        public CharProDataAccess(CharProDbContext dbCtx2)
        {
            this._dbCtx2 = dbCtx2;

        }
        public void AddPro(CharPro p)
        {
            _dbCtx2.CharPros.Add(p);
            _dbCtx2.SaveChanges();
        }

        public List<CharPro> GetPro()
        {
            return _dbCtx2.CharPros.ToList();
        }

        public CharPro GetProById(int ProId)
        {
            var record = _dbCtx2.CharPros.Find(ProId);
            if (record != null)
            {
                return record;
            }
            else
            {
                throw new Exception("Record Not Found");
            }
        }

        public void UpdatePro(CharPro p)
        {
            var record = _dbCtx2.CharPros.Find(p.ProId);
            if (record != null)
            {
                record.Proname = p.Proname;
                record.Contact = p.Contact;
                record.Website = p.Website;
               
                _dbCtx2.SaveChanges();

            }
            else
            {
                throw new Exception("Record not Found");
            }
        }
    }
}
