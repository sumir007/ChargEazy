﻿namespace Chargeazy.Models
{
    public class RevDataAccess : IRevDataAccess
    {
        readonly RevDbContext _dbCtx3;
        public RevDataAccess(RevDbContext dbCtx3)
        {
            this._dbCtx3 = dbCtx3;

        }
        public void AddRev(Review r)
        {
            _dbCtx3.Reviews.Add(r);
            _dbCtx3.SaveChanges();
        }

        public List<Review> GetRev()
        {
            return _dbCtx3.Reviews.ToList();
        }

        public Review GetRevById(int RevId)
        {
            var record = _dbCtx3.Reviews.Find(RevId);
            if (record != null)
            {
                return record;
            }
            else
            {
                throw new Exception("Record Not Found");
            }
        }
    }
}
