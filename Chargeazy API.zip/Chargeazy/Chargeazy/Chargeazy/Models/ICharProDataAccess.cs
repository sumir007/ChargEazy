﻿namespace Chargeazy.Models
{
    public interface ICharProDataAccess
    {
        List<CharPro> GetPro();
        CharPro GetProById(int ProId);
        void AddPro(CharPro p);
        void UpdatePro(CharPro p);
    }
}
