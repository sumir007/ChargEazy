﻿namespace Chargeazy.Models
{
    public class CharPro
    {
        public int ProId { get; set; }    
        public string Proname { get; set; } 
        public string Contact { get; set; }    
        public string Website { get; set; } 

    }
}
