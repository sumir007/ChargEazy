﻿using Microsoft.EntityFrameworkCore;

namespace Chargeazy.Models
{
    public class CharStn
    {
        public int StationId { get; set; }
        
        public string Stationname { get; set;}
        public string Location { get; set;}
        public string Address { get; set; }
        public int ProviderId { get; set; }
        public int  ChargingCapacity { get; set;} 
        public string Status { get; set;}
       
        }
   
    

}
