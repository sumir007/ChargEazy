using Microsoft.AspNetCore.Mvc;
using Chargeazy.Models;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Chargeazy.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChargeEazyController : ControllerBase
    {
        readonly IUserDataAccess dal;
        readonly ICharStnDataAccess dal1;
        readonly ICharProDataAccess dal2;
        readonly IRevDataAccess dal3;
        public ChargeEazyController(IUserDataAccess dal, ICharStnDataAccess dal1, ICharProDataAccess dal2, IRevDataAccess dal3)
        {
            this.dal = dal;
            this.dal1 = dal1;
            this.dal2 = dal2;
            this.dal3 = dal3;   
        }
        // GET: api/<employees_Controller>
        [HttpGet("GetAllUser")]
        //[Route("GetAllEmployees")]
        public IEnumerable<User> Get()
        {
            return dal.GetUser();
        }

        // GET api/<employees_Controller>/5
        [HttpGet("GetPasswordByID/{Email}")]
        //[Route("GetEmployeeById/{id}")]
        //public IActionResult Get(int UserId)
        //{

        //    try
        //    {
        //        return Ok(dal.GetUserById(UserId));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}
        public ActionResult<string> Get(string Email)
        {
            string storedPassword = dal.GetUserById(Email);

            if (string.IsNullOrEmpty(storedPassword))
            {
                return NotFound("Username not found");
            }

            return Ok(storedPassword);
        }


        // POST api/<employees_Controller>
        [HttpPost("AddUser")]
        public void Post([FromBody] User u)
        {
            dal.AddUser(u);
        }

        // PUT api/<employees_Controller>/5
        [HttpPut("UpdateUser/{UserId}")]
        public void Put(int UserId, [FromBody] User u)
        {
            dal.UpdateUser(u);
        }

        // DELETE api/<employees_Controller>/5
        [HttpDelete("DeleteUserById/{UserId}")]
        public void Delete(int UserId)
        {

            dal.DeleteUser(UserId);
        }








        //*
        [HttpGet("GetAllCharStn")]
        //[Route("GetAllEmployees")]
        public IEnumerable<CharStn> Get1()
        {
            return dal1.GetStn();
        }

        // GET api/<employees_Controller>/5
        [HttpGet("GetStnById/{StationId}")]
        //[Route("GetEmployeeById/{id}")]
        public IActionResult Get1(int StationId)
        {

            try
            {
                return Ok(dal1.GetStnById(StationId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        //ChargingStation
        [HttpPost("AddStn")]
        public void Post([FromBody] CharStn c)
        {
            dal1.AddStn(c);
        }

        // PUT api/<employees_Controller>/5
        [HttpPut("UpdateStnById/{StationId}")]
        public void Put1(int StationId, [FromBody] CharStn c)
        {
            dal1.UpdateStn(c);
        }














        //*
        [HttpGet("GetAllCharPro")]
        //[Route("GetAllEmployees")]
        public IEnumerable<CharPro> Get2()
        {
            return dal2.GetPro();
        }

        // GET api/<employees_Controller>/5
        [HttpGet("GetProById/{ProId}")]
        //[Route("GetEmployeeById/{id}")]
        public IActionResult Get2(int ProId)
        {

            try
            {
                return Ok(dal2.GetProById(ProId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        //**
        //ChargingStation
        [HttpPost("AddPro")]
        public void Post([FromBody] CharPro p)
        {
            dal2.AddPro(p);
        }

        // PUT api/<employees_Controller>/5
        [HttpPut("UpdateProById/{StationId}")]
        public void Put2(int ProId, [FromBody] CharPro p)
        {
            dal2.UpdatePro(p);
        }












        //*
        [HttpGet("GetAllReview")]
        //[Route("GetAllEmployees")]
        public IEnumerable<Review> Get3()
        {
            return dal3.GetRev();
        }

        // GET api/<employees_Controller>/5
        [HttpGet("GetRevById/{RevId}")]
        //[Route("GetEmployeeById/{id}")]
        public IActionResult Get3(int RevId)
        {

            try
            {
                return Ok(dal3.GetRevById(RevId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        //**
        //ChargingStation
        [HttpPost("AddReview")]
        public void Post([FromBody] Review r)
        {
            dal3.AddRev(r);
        }
    }
}
